/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class HistoriaPrecio {
    private int id_Historial;
    private int Precio_Anterior;
    private int Precio_Nuevo;
    private int Fecha_Cambio;
    private char Comentario;
    private int id_Producto;

    public HistoriaPrecio(int id_Historial, int Precio_Anterior, int Precio_Nuevo, int Fecha_Cambio, char Comentario, int id_Producto) {
        this.id_Historial = id_Historial;
        this.Precio_Anterior = Precio_Anterior;
        this.Precio_Nuevo = Precio_Nuevo;
        this.Fecha_Cambio = Fecha_Cambio;
        this.Comentario = Comentario;
        this.id_Producto = id_Producto;
    }

    public int getId_Historial() {
        return id_Historial;
    }

    public void setId_Historial(int id_Historial) {
        this.id_Historial = id_Historial;
    }

    public int getPrecio_Anterior() {
        return Precio_Anterior;
    }

    public void setPrecio_Anterior(int Precio_Anterior) {
        this.Precio_Anterior = Precio_Anterior;
    }

    public int getPrecio_Nuevo() {
        return Precio_Nuevo;
    }

    public void setPrecio_Nuevo(int Precio_Nuevo) {
        this.Precio_Nuevo = Precio_Nuevo;
    }

    public int getFecha_Cambio() {
        return Fecha_Cambio;
    }

    public void setFecha_Cambio(int Fecha_Cambio) {
        this.Fecha_Cambio = Fecha_Cambio;
    }

    public char getComentario() {
        return Comentario;
    }

    public void setComentario(char Comentario) {
        this.Comentario = Comentario;
    }

    public int getId_Producto() {
        return id_Producto;
    }

    public void setId_Producto(int id_Producto) {
        this.id_Producto = id_Producto;
    }

    @Override
    public String toString() {
        return "HistoriaPrecio{" + "id_Historial=" + id_Historial + ", Precio_Anterior=" + Precio_Anterior + ", Precio_Nuevo=" + Precio_Nuevo + ", Fecha_Cambio=" + Fecha_Cambio + ", Comentario=" + Comentario + ", id_Producto=" + id_Producto + '}';
    }
    
    
}
