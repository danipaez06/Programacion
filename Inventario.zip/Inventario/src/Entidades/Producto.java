/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Producto {
    private int id_Producto;
    private char Nombre;
    private int Referencia;
    private char Descripcion;
    private int Precio_Unitario;
    private int id_Categoria;
    private int id_Proveedor;
    private char Fecha_registro;
    private char Estado;

    public Producto(int id_Producto, char Nombre, int Referencia, char Descripcion, int Precio_Unitario, int id_Categoria, int id_Proveedor, char Fecha_registro, char Estado) {
        this.id_Producto = id_Producto;
        this.Nombre = Nombre;
        this.Referencia = Referencia;
        this.Descripcion = Descripcion;
        this.Precio_Unitario = Precio_Unitario;
        this.id_Categoria = id_Categoria;
        this.id_Proveedor = id_Proveedor;
        this.Fecha_registro = Fecha_registro;
        this.Estado = Estado;
    }

    public int getId_Producto() {
        return id_Producto;
    }

    public void setId_Producto(int id_Producto) {
        this.id_Producto = id_Producto;
    }

    public char getNombre() {
        return Nombre;
    }

    public void setNombre(char Nombre) {
        this.Nombre = Nombre;
    }

    public int getReferencia() {
        return Referencia;
    }

    public void setReferencia(int Referencia) {
        this.Referencia = Referencia;
    }

    public char getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(char Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getPrecio_Unitario() {
        return Precio_Unitario;
    }

    public void setPrecio_Unitario(int Precio_Unitario) {
        this.Precio_Unitario = Precio_Unitario;
    }

    public int getId_Categoria() {
        return id_Categoria;
    }

    public void setId_Categoria(int id_Categoria) {
        this.id_Categoria = id_Categoria;
    }

    public int getId_Proveedor() {
        return id_Proveedor;
    }

    public void setId_Proveedor(int id_Proveedor) {
        this.id_Proveedor = id_Proveedor;
    }

    public char getFecha_registro() {
        return Fecha_registro;
    }

    public void setFecha_registro(char Fecha_registro) {
        this.Fecha_registro = Fecha_registro;
    }

    public char getEstado() {
        return Estado;
    }

    public void setEstado(char Estado) {
        this.Estado = Estado;
    }

    @Override
    public String toString() {
        return "Producto{" + "id_Producto=" + id_Producto + ", Nombre=" + Nombre + ", Referencia=" + Referencia + ", Descripcion=" + Descripcion + ", Precio_Unitario=" + Precio_Unitario + ", id_Categoria=" + id_Categoria + ", id_Proveedor=" + id_Proveedor + ", Fecha_registro=" + Fecha_registro + ", Estado=" + Estado + '}';
    }
    
    
}
