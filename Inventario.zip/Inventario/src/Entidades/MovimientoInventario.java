/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class MovimientoInventario {
    private int id_Movimiento;
    private int id_Producto;
    private char Tipo;
    private int Cantidad;
    private int id_Categoria;
    private int Fecha_Movimiento;
    private char Observaciones;
    private int id_Usuario;

    public MovimientoInventario(int id_Movimiento, int id_Producto, char Tipo, int Cantidad, int id_Categoria, int Fecha_Movimiento, char Observaciones, int id_Usuario) {
        this.id_Movimiento = id_Movimiento;
        this.id_Producto = id_Producto;
        this.Tipo = Tipo;
        this.Cantidad = Cantidad;
        this.id_Categoria = id_Categoria;
        this.Fecha_Movimiento = Fecha_Movimiento;
        this.Observaciones = Observaciones;
        this.id_Usuario = id_Usuario;
    }

    public int getId_Movimiento() {
        return id_Movimiento;
    }

    public void setId_Movimiento(int id_Movimiento) {
        this.id_Movimiento = id_Movimiento;
    }

    public int getId_Producto() {
        return id_Producto;
    }

    public void setId_Producto(int id_Producto) {
        this.id_Producto = id_Producto;
    }

    public char getTipo() {
        return Tipo;
    }

    public void setTipo(char Tipo) {
        this.Tipo = Tipo;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public int getId_Categoria() {
        return id_Categoria;
    }

    public void setId_Categoria(int id_Categoria) {
        this.id_Categoria = id_Categoria;
    }

    public int getFecha_Movimiento() {
        return Fecha_Movimiento;
    }

    public void setFecha_Movimiento(int Fecha_Movimiento) {
        this.Fecha_Movimiento = Fecha_Movimiento;
    }

    public char getObservaciones() {
        return Observaciones;
    }

    public void setObservaciones(char Observaciones) {
        this.Observaciones = Observaciones;
    }

    public int getId_Usuario() {
        return id_Usuario;
    }

    public void setId_Usuario(int id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    @Override
    public String toString() {
        return "MovimientoInventario{" + "id_Movimiento=" + id_Movimiento + ", id_Producto=" + id_Producto + ", Tipo=" + Tipo + ", Cantidad=" + Cantidad + ", id_Categoria=" + id_Categoria + ", Fecha_Movimiento=" + Fecha_Movimiento + ", Observaciones=" + Observaciones + ", id_Usuario=" + id_Usuario + '}';
    }
    
    
}
