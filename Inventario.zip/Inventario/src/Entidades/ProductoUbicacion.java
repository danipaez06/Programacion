/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class ProductoUbicacion {
    private int id_Producto;
    private int id_Ubicacion;
    private int cantidad_en_Ubicacion;

    public ProductoUbicacion(int id_Producto, int id_Ubicacion, int cantidad_en_Ubicacion) {
        this.id_Producto = id_Producto;
        this.id_Ubicacion = id_Ubicacion;
        this.cantidad_en_Ubicacion = cantidad_en_Ubicacion;
    }

    public int getId_Producto() {
        return id_Producto;
    }

    public void setId_Producto(int id_Producto) {
        this.id_Producto = id_Producto;
    }

    public int getId_Ubicacion() {
        return id_Ubicacion;
    }

    public void setId_Ubicacion(int id_Ubicacion) {
        this.id_Ubicacion = id_Ubicacion;
    }

    public int getCantidad_en_Ubicacion() {
        return cantidad_en_Ubicacion;
    }

    public void setCantidad_en_Ubicacion(int cantidad_en_Ubicacion) {
        this.cantidad_en_Ubicacion = cantidad_en_Ubicacion;
    }

    @Override
    public String toString() {
        return "ProductoUbicacion{" + "id_Producto=" + id_Producto + ", id_Ubicacion=" + id_Ubicacion + ", cantidad_en_Ubicacion=" + cantidad_en_Ubicacion + '}';
    }
    
    
}
