/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class CategoriaProducto {
    private int id_Categoria;
    private char Nombre;
    private char Descripcion;

    public CategoriaProducto(int id_Categoria, char Nombre, char Descripcion) {
        this.id_Categoria = id_Categoria;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
    }

    public int getId_Categoria() {
        return id_Categoria;
    }

    public void setId_Categoria(int id_Categoria) {
        this.id_Categoria = id_Categoria;
    }

    public char getNombre() {
        return Nombre;
    }

    public void setNombre(char Nombre) {
        this.Nombre = Nombre;
    }

    public char getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(char Descripcion) {
        this.Descripcion = Descripcion;
    }

    @Override
    public String toString() {
        return "CategoriaProducto{" + "id_Categoria=" + id_Categoria + ", Nombre=" + Nombre + ", Descripcion=" + Descripcion + '}';
    }
    
    
}
