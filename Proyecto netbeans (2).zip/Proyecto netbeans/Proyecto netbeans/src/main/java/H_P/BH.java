/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package H_P;

/**
 *
 * @author RPR-C80A404ES
 */
public class BH {
    
    private String nombre;
    private String sede;
    private String direccion;

    public BH(String nombre, String sede, String direccion) {
        this.nombre = nombre;
        this.sede = sede;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getSede() {
        return sede;
    }

    public String getDireccion() {
        return direccion;
    }

    @Override
    public String toString() {
        return "BH{" + "nombre=" + nombre + ", sede=" + sede + ", direccion=" + direccion + '}';
    }
    
    
    
}
