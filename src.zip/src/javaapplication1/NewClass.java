/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author RPR-C80A404ES
 */
public class NewClass {
    private String Direc;
    private String Nom;
    private String Com;
    private String Est;
    private String Pes;

    public NewClass(String Direc, String Nom, String Com, String Est, String Pes) {
        this.Direc = Direc;
        this.Nom = Nom;
        this.Com = Com;
        this.Est = Est;
        this.Pes = Pes;
    }

    public String getDirec() {
        return Direc;
    }

    public void setDirec(String Direc) {
        this.Direc = Direc;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public String getCom() {
        return Com;
    }

    public void setCom(String Com) {
        this.Com = Com;
    }

    public String getEst() {
        return Est;
    }

    public void setEst(String Est) {
        this.Est = Est;
    }

    public String getPes() {
        return Pes;
    }

    public void setPes(String Pes) {
        this.Pes = Pes;
    }

    @Override
    public String toString() {
        return "NewClass{" + "Direc=" + Direc + ", Nom=" + Nom + ", Com=" + Com + ", Est=" + Est + ", Pes=" + Pes + '}';
    }
    
    
}
